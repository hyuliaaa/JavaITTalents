package com.example.s13firstspringproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S13FirstSpringProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
